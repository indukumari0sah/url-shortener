# URL Shortener — Project Report
**Submitted by:** Indukumari Sah  
**Project category:** Web Development Internship Project

## 1. Abstract
The URL Shortener is a full-stack web application that converts long web addresses into compact links. A user submits a valid HTTP or HTTPS URL. The server creates a unique short code, stores the mapping in MongoDB and returns a short URL. When a visitor opens that short URL, the application retrieves the saved destination and redirects the visitor to the original page.

## 2. Problem Statement
Long URLs can be difficult to copy, share and manage. The project provides a simple interface for creating shorter links and keeps a record of recently created links in a database.

## 3. Objectives
- Build a simple, responsive web interface.
- Accept and validate a long URL.
- Generate a unique short code.
- Store original URLs and codes in MongoDB.
- Redirect visitors using route parameters.
- Use a MongoDB index to retrieve short codes efficiently.
- Count link visits and display recent links.

## 4. Technology Stack
- HTML: page structure.
- CSS: layout, typography and responsive design.
- JavaScript: form handling, API requests and copy-link action.
- Node.js: JavaScript runtime for the server.
- Express.js: API routes and redirect handling.
- MongoDB: persistent document database.
- Mongoose: schema, validation and database operations.

## 5. System Design
The browser sends the entered URL to `POST /api/shorten`. Express validates the URL and generates an eight-character hexadecimal code. Mongoose stores the original URL, code, click count and creation date in MongoDB. The server returns a short URL based on the configured `BASE_URL`. When that code is opened, `GET /:code` looks up the record using the indexed `shortCode` field, increments the click count and sends an HTTP 302 redirect.

## 6. Database Design
Collection: `shorturls`

| Field | Type | Purpose |
|---|---|---|
| originalUrl | String | Destination URL |
| shortCode | String | Unique short identifier |
| clicks | Number | Number of redirects |
| createdAt | Date | Creation timestamp |

A unique index on `shortCode` prevents duplicate codes and supports efficient lookup.

## 7. Main Modules
1. Frontend module — URL input, result display, recent links and copy button.
2. URL validation module — accepts HTTP/HTTPS URLs and rejects malformed input.
3. Short-code generation module — uses Node.js cryptographic random bytes.
4. Database module — stores and fetches URL records through Mongoose.
5. Redirect module — reads a route parameter and redirects to the original destination.
6. Visit tracking module — increments the click count on redirects.

## 8. API Design
- `POST /api/shorten`: creates and saves a short URL.
- `GET /:code`: redirects to the original URL.
- `GET /api/urls`: lists the latest 20 saved links.
- `GET /api/health`: reports server/database connection state.

## 9. Testing Plan
- Valid HTTPS URL creates a short link.
- Short link redirects to the correct destination.
- Recent links remain after server restart when MongoDB is connected.
- Invalid URL input produces an error.
- Unknown short codes return a 404 response.
- Click count increments when a short link is visited.
- Unique index prevents duplicate short codes.

Record the actual test result and date after running each test on your own computer.

## 10. Security and Limitations
Only HTTP and HTTPS protocols are accepted. The application uses generated codes and server-side validation. A production deployment should add rate limiting, abuse prevention, logging, monitoring, privacy information and protections against phishing or malicious links. The local development URL is not accessible from the public internet. Public deployment requires hosting and a public HTTPS base URL.

## 11. Future Scope
- User accounts and personal link dashboards.
- Expiration dates and custom aliases.
- QR-code generation.
- More detailed click analytics.
- Rate limiting and suspicious-link reporting.
- Public deployment.

## 12. Conclusion
The project demonstrates frontend development, REST API design, route parameters, URL validation, database schema design, MongoDB indexing and HTTP redirects. It provides a foundation for understanding a complete full-stack web application.
