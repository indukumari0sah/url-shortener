require("dotenv").config();

const express = require("express");
const mongoose = require("mongoose");
const crypto = require("crypto");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const BASE_URL = (process.env.BASE_URL || `http://localhost:${PORT}`).replace(/\/+$/, "");

app.use(express.json({ limit: "10kb" }));
app.use(express.static(path.join(__dirname, "public")));

const urlSchema = new mongoose.Schema({
  originalUrl: {
    type: String,
    required: true,
    maxlength: 2048
  },
  shortCode: {
    type: String,
    required: true,
    unique: true,
    index: true
  },
  clicks: {
    type: Number,
    default: 0
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Unique index lets MongoDB enforce that every short code is unique.
urlSchema.index({ shortCode: 1 }, { unique: true });

const ShortUrl = mongoose.model("ShortUrl", urlSchema);

function normalizeUrl(value) {
  if (typeof value !== "string" || !value.trim()) {
    throw new Error("Please enter a URL.");
  }

  let parsed;
  try {
    parsed = new URL(value.trim());
  } catch {
    throw new Error("Please enter a valid URL, including https://");
  }

  if (!["http:", "https:"].includes(parsed.protocol)) {
    throw new Error("Only HTTP and HTTPS links are allowed.");
  }

  if (!parsed.hostname || parsed.hostname.includes(" ")) {
    throw new Error("Please enter a valid website address.");
  }

  return parsed.href;
}

app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    database: mongoose.connection.readyState === 1 ? "connected" : "disconnected"
  });
});

app.post("/api/shorten", async (req, res) => {
  try {
    const originalUrl = normalizeUrl(req.body.originalUrl);

    // Try a few times in the extremely unlikely event of a code collision.
    let saved;
    for (let attempt = 0; attempt < 5; attempt++) {
      const shortCode = crypto.randomBytes(4).toString("hex");
      try {
        saved = await ShortUrl.create({ originalUrl, shortCode });
        break;
      } catch (error) {
        if (error.code !== 11000 || attempt === 4) throw error;
      }
    }

    return res.status(201).json({
      originalUrl: saved.originalUrl,
      shortCode: saved.shortCode,
      shortUrl: `${BASE_URL}/${saved.shortCode}`,
      clicks: saved.clicks,
      createdAt: saved.createdAt
    });
  } catch (error) {
    if (error.message && (
      error.message.startsWith("Please enter") ||
      error.message.startsWith("Only HTTP")
    )) {
      return res.status(400).json({ error: error.message });
    }
    console.error("Could not shorten URL:", error.message);
    return res.status(500).json({
      error: "Could not create the short link. Check the server and database settings."
    });
  }
});

app.get("/api/urls", async (req, res) => {
  try {
    const urls = await ShortUrl.find()
      .sort({ createdAt: -1 })
      .limit(20)
      .select("originalUrl shortCode clicks createdAt")
      .lean();

    res.json(urls.map((item) => ({
      ...item,
      shortUrl: `${BASE_URL}/${item.shortCode}`
    })));
  } catch (error) {
    console.error("Could not fetch URLs:", error.message);
    res.status(500).json({ error: "Could not load recent links." });
  }
});

app.get("/:code", async (req, res, next) => {
  const { code } = req.params;

  // Codes created by this app are exactly eight lowercase hex characters.
  if (!/^[a-f0-9]{8}$/.test(code)) {
    return res.status(404).send("Short link not found.");
  }

  try {
    // findOne uses the indexed shortCode field.
    const record = await ShortUrl.findOneAndUpdate(
      { shortCode: code },
      { $inc: { clicks: 1 } },
      { new: true }
    );

    if (!record) return res.status(404).send("Short link not found.");

    return res.redirect(302, record.originalUrl);
  } catch (error) {
    return next(error);
  }
});

app.use((error, req, res, next) => {
  console.error(error);
  if (res.headersSent) return next(error);
  res.status(500).send("Something went wrong on the server.");
});

async function start() {
  if (!process.env.MONGODB_URI) {
    console.error("Missing MONGODB_URI. Copy .env.example to .env and add your MongoDB connection string.");
    process.exit(1);
  }

  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log("Connected to MongoDB.");
    await ShortUrl.init(); // Ensure the unique index is built.
    app.listen(PORT, () => {
      console.log(`URL Shortener running at ${BASE_URL}`);
    });
  } catch (error) {
    console.error("Startup failed:", error.message);
    process.exit(1);
  }
}

start();