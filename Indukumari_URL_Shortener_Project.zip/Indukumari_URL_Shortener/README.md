# QuickLink — URL Shortener
**Internship project by Indukumari Sah**

A full-stack URL Shortener built with HTML, CSS, JavaScript, Node.js, Express and MongoDB.

## Features
- Convert long HTTP/HTTPS URLs into short links.
- Redirect short links to their original destination.
- Store links in MongoDB so they persist after a server restart.
- Unique short codes enforced by a MongoDB unique index.
- Track redirect click counts.
- Recent links list and copy-link button.
- Basic input validation and responsive interface.

## Requirements
- Node.js 18 or newer
- MongoDB Atlas account (or a local MongoDB server)
- VS Code (recommended)

## Setup
1. Extract the project ZIP and open the folder in VS Code.
2. Open a terminal in this folder and run:
   ```bash
   npm install
   ```
3. Copy `.env.example` to a new file named `.env`.
   - Windows PowerShell: `Copy-Item .env.example .env`
   - macOS/Linux: `cp .env.example .env`
4. In `.env`, replace `MONGODB_URI` with your MongoDB connection string. Keep the database name `url_shortener` or change it if desired.
5. Keep `BASE_URL=http://localhost:3000` for local testing.
6. Start the app:
   ```bash
   npm start
   ```
7. Open `http://localhost:3000` in your browser.

## MongoDB Atlas quick setup
1. Create a free MongoDB Atlas project and cluster.
2. Create a database user and save its password securely.
3. In Network Access, allow your current IP address.
4. Select Connect → Drivers → Node.js and copy the connection string.
5. Paste it into `.env` as `MONGODB_URI`. URL-encode special characters in the password if needed.
6. Never upload `.env` or your database password to GitHub.

## Test cases
1. Enter `https://www.google.com` and click Shorten link. A short URL should appear.
2. Open the short URL in a new tab; it should redirect to Google.
3. Refresh the homepage; the link should remain in Recent links.
4. Enter invalid text; browser validation or server validation should show an error.
5. Open an unknown code such as `http://localhost:3000/ffffffff`; it should show “Short link not found” unless that code was actually generated.
6. Open `/api/health` to check server and database status.

## API endpoints
- `POST /api/shorten` — JSON body: `{ "originalUrl": "https://example.com" }`
- `GET /:code` — redirects to the saved original URL.
- `GET /api/urls` — returns up to 20 most recent links.
- `GET /api/health` — returns application and database status.

## Project structure
```text
Indukumari_URL_Shortener/
├── public/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── server.js
├── package.json
├── .env.example
├── .gitignore
├── README.md
└── PROJECT_REPORT.md
```

## Important notes
- The app needs a working MongoDB connection before it starts.
- The generated short links use your current base URL. `localhost` links only work on your own computer; a deployed app needs a public HTTPS `BASE_URL`.
- Before public deployment, add rate limiting, abuse reporting, stronger operational monitoring and a policy for unsafe/malicious destinations.
- Do not commit credentials or `.env` to GitHub.
