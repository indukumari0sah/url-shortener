const form = document.getElementById("urlForm");
const input = document.getElementById("originalUrl");
const button = document.getElementById("shortenBtn");
const message = document.getElementById("message");
const result = document.getElementById("result");
const shortUrl = document.getElementById("shortUrl");
const originalPreview = document.getElementById("originalPreview");
const copyBtn = document.getElementById("copyBtn");
const recentLinks = document.getElementById("recentLinks");
const refreshBtn = document.getElementById("refreshBtn");

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  message.textContent = "";
  result.classList.add("hidden");
  button.disabled = true;
  button.textContent = "Creating...";

  try {
    const response = await fetch("/api/shorten", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ originalUrl: input.value.trim() })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not create link.");

    shortUrl.href = data.shortUrl;
    shortUrl.textContent = data.shortUrl;
    originalPreview.textContent = `Original: ${data.originalUrl}`;
    result.classList.remove("hidden");
    input.value = "";
    await loadRecentLinks();
  } catch (error) {
    message.textContent = error.message || "Could not connect to the server.";
  } finally {
    button.disabled = false;
    button.innerHTML = 'Shorten link <span aria-hidden="true">→</span>';
  }
});

copyBtn.addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(shortUrl.href);
    copyBtn.textContent = "Copied!";
    setTimeout(() => { copyBtn.textContent = "Copy link"; }, 1600);
  } catch {
    message.textContent = "Copy failed. Select and copy the link manually.";
  }
});

async function loadRecentLinks() {
  recentLinks.innerHTML = '<p class="empty-state">Loading recent links…</p>';
  try {
    const response = await fetch("/api/urls");
    const items = await response.json();
    if (!response.ok) throw new Error(items.error || "Could not load links.");

    if (!items.length) {
      recentLinks.innerHTML = '<p class="empty-state">No links yet. Create your first short link above.</p>';
      return;
    }

    recentLinks.replaceChildren();
    items.forEach((item) => {
      const row = document.createElement("article");
      row.className = "recent-item";
      const details = document.createElement("div");
      const link = document.createElement("a");
      link.href = item.shortUrl;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = item.shortUrl;
      const original = document.createElement("p");
      original.textContent = item.originalUrl;
      details.append(link, original);

      const clicks = document.createElement("span");
      clicks.className = "clicks";
      clicks.textContent = `${item.clicks} clicks`;
      row.append(details, clicks);
      recentLinks.append(row);
    });
  } catch {
    recentLinks.innerHTML = '<p class="empty-state">Could not load links. Check that the server and MongoDB are running.</p>';
  }
}

refreshBtn.addEventListener("click", loadRecentLinks);
loadRecentLinks();